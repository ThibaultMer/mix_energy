"""Mix Energy FastAPI package."""
