variable "project_id" {
  description = "Unique GCP project ID."
  type        = string
}

variable "project_name" {
  description = "Display name of the GCP project."
  type        = string
}

variable "billing_account" {
  description = "Billing account attached to the project."
  type        = string
}

variable "gcp_user_email" {
  description = "Primary user email granted project access."
  type        = string
}

variable "project_bucket_name" {
  description = "Name of the main project bucket."
  type        = string
}

variable "location" {
  description = "BigQuery and storage multi-region/location."
  type        = string
  default     = "EU"
}

variable "artifact_registry_location" {
  description = "Region used for Artifact Registry and compute resources."
  type        = string
  default     = "europe-west1"
}

variable "repository_id" {
  description = "Artifact Registry repository ID."
  type        = string
  default     = "mix-energie-airflow"
}

variable "vm_name" {
  description = "Name of the compute instance."
  type        = string
  default     = "vm-mix-energie"
}

variable "vm_zone" {
  description = "Zone for the compute instance."
  type        = string
  default     = "europe-west1-b"
}

variable "vm_machine_type" {
  description = "Machine type for the compute instance."
  type        = string
  default     = "e2-micro"
}

variable "vm_image_family" {
  description = "Image family for the compute instance boot disk."
  type        = string
  default     = "debian-11"
}

variable "vm_image_project" {
  description = "Image project for the compute instance boot disk."
  type        = string
  default     = "debian-cloud"
}

variable "bootstrap_only" {
  description = "Reserved flag to keep parity with legacy env vars."
  type        = bool
  default     = false
}

variable "create_demo_resources" {
  description = "Reserved flag to keep parity with legacy env vars."
  type        = bool
  default     = false
}

variable "bigquery_datasets" {
  description = "Business datasets to create in BigQuery."
  type        = list(string)
  default = [
    "dev_mix_energie",
    "dev_mix_energie_gold",
    "dev_mix_energie_silver",
    "prod_mix_energie",
    "prod_mix_energie_gold",
    "prod_mix_energie_silver",
  ]
}