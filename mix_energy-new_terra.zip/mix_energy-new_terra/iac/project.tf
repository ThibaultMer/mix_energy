resource "google_project" "mix_energy" {
  project_id          = var.project_id
  name                = var.project_name
  billing_account     = var.billing_account
  auto_create_network = false

  labels = local.common_labels
}