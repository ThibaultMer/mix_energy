resource "google_project_service" "required" {
  for_each = local.required_services

  project            = google_project.mix_energy.project_id
  service            = each.value
  disable_on_destroy = false
}