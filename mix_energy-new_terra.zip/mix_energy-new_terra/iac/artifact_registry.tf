resource "google_artifact_registry_repository" "airflow" {
  project       = google_project.mix_energy.project_id
  location      = var.artifact_registry_location
  repository_id = var.repository_id
  description   = "Docker images for mix-energy workloads"
  format        = "DOCKER"

  labels = local.common_labels

  depends_on = [google_project_service.required]
}