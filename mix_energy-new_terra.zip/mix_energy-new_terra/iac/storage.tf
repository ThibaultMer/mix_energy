resource "google_storage_bucket" "project_bucket" {
  name                        = var.project_bucket_name
  project                     = google_project.mix_energy.project_id
  location                    = var.location
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = false

  versioning {
    enabled = true
  }

  labels = local.common_labels

  depends_on = [google_project_service.required]
}