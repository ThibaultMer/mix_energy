resource "google_bigquery_dataset" "datasets" {
  for_each = toset(var.bigquery_datasets)

  project                    = google_project.mix_energy.project_id
  dataset_id                 = each.value
  location                   = var.location
  delete_contents_on_destroy = false

  labels = local.common_labels

  depends_on = [google_project_service.required]
}