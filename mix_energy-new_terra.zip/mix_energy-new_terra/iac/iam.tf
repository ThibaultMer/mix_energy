resource "google_project_iam_member" "project_owner" {
  project = google_project.mix_energy.project_id
  role    = "roles/owner"
  member  = "user:${var.gcp_user_email}"

  depends_on = [google_project_service.required]
}

resource "google_service_account" "runtime" {
  for_each = local.service_accounts

  project      = google_project.mix_energy.project_id
  account_id   = each.value.account_id
  display_name = each.value.display_name

  depends_on = [google_project_service.required]
}

resource "google_project_iam_member" "service_account_roles" {
  for_each = local.service_account_bindings

  project = google_project.mix_energy.project_id
  role    = each.value.role
  member  = "serviceAccount:${google_service_account.runtime[each.value.name].email}"

  depends_on = [google_service_account.runtime]
}