output "project_id" {
  description = "Created GCP project ID."
  value       = google_project.mix_energy.project_id
}

output "project_number" {
  description = "Created GCP project number."
  value       = google_project.mix_energy.number
}

output "bucket_name" {
  description = "Main project storage bucket."
  value       = google_storage_bucket.project_bucket.name
}

output "artifact_registry_repository" {
  description = "Artifact Registry repository resource name."
  value       = google_artifact_registry_repository.airflow.name
}

output "vm_name" {
  description = "Compute instance name."
  value       = google_compute_instance.vm.name
}

output "bigquery_datasets" {
  description = "Managed business datasets."
  value       = sort(keys(google_bigquery_dataset.datasets))
}

output "service_account_emails" {
  description = "Service accounts created for workloads."
  value = {
    for name, account in google_service_account.runtime : name => account.email
  }
}