project_id                 = "mix-energie-gcp12"
project_name               = "mix-energie-gcp12"
project_bucket_name        = "mix-energie-bucket-gcp12"
gcp_user_email             = "jccharbo1@gmail.com"
billing_account            = "01FE1B-B3B34E-92A1B4"
location                   = "EU"
artifact_registry_location = "europe-west1"
repository_id              = "mix-energie-airflow"
vm_name                    = "vm-mix-energie"
vm_zone                    = "europe-west1-b"
vm_machine_type            = "e2-micro"
vm_image_family            = "debian-11"
vm_image_project           = "debian-cloud"
bootstrap_only             = false
create_demo_resources      = false

bigquery_datasets = [
  "dev_mix_energie",
  "dev_mix_energie_gold",
  "dev_mix_energie_silver",
  "prod_mix_energie",
  "prod_mix_energie_gold",
  "prod_mix_energie_silver",
]