resource "google_compute_network" "main" {
  name                    = "mix-energy-network"
  project                 = google_project.mix_energy.project_id
  auto_create_subnetworks = false

  depends_on = [google_project_service.required]
}

resource "google_compute_subnetwork" "main" {
  name          = "mix-energy-subnetwork"
  project       = google_project.mix_energy.project_id
  region        = local.vm_region
  ip_cidr_range = "10.12.0.0/24"
  network       = google_compute_network.main.id

  depends_on = [google_project_service.required]
}

resource "google_compute_firewall" "allow_iap_ssh" {
  name    = "allow-iap-ssh"
  project = google_project.mix_energy.project_id
  network = google_compute_network.main.name

  allow {
    protocol = "tcp"
    ports    = ["22"]
  }

  source_ranges = ["35.235.240.0/20"]
  target_tags   = ["ssh-enabled"]

  depends_on = [google_project_service.required]
}

resource "google_compute_instance" "vm" {
  name         = var.vm_name
  project      = google_project.mix_energy.project_id
  zone         = var.vm_zone
  machine_type = var.vm_machine_type
  tags         = ["ssh-enabled", "mix-energy"]

  boot_disk {
    initialize_params {
      image = "projects/${var.vm_image_project}/global/images/family/${var.vm_image_family}"
      size  = 20
      type  = "pd-balanced"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.main.id

    access_config {}
  }

  metadata = {
    enable-oslogin = "TRUE"
  }

  service_account {
    email  = google_service_account.runtime["vm"].email
    scopes = ["cloud-platform"]
  }

  labels = local.common_labels

  depends_on = [
    google_compute_firewall.allow_iap_ssh,
    google_service_account.runtime,
  ]
}