locals {
  common_labels = {
    application = "mix-energy"
    environment = "gcp12"
    managed_by  = "terraform"
  }

  vm_region = join("-", slice(split("-", var.vm_zone), 0, length(split("-", var.vm_zone)) - 1))

  required_services = toset([
    "artifactregistry.googleapis.com",
    "bigquery.googleapis.com",
    "cloudresourcemanager.googleapis.com",
    "compute.googleapis.com",
    "iam.googleapis.com",
    "serviceusage.googleapis.com",
    "storage.googleapis.com",
  ])

  service_accounts = {
    airflow = {
      account_id   = "airflow-runtime"
      display_name = "Airflow runtime service account"
      roles = [
        "roles/artifactregistry.reader",
        "roles/bigquery.admin",
        "roles/storage.admin",
      ]
    }
    fastapi = {
      account_id   = "fastapi-runtime"
      display_name = "FastAPI runtime service account"
      roles = [
        "roles/bigquery.dataViewer",
        "roles/bigquery.jobUser",
      ]
    }
    streamlit = {
      account_id   = "streamlit-runtime"
      display_name = "Streamlit runtime service account"
      roles = [
        "roles/bigquery.dataViewer",
        "roles/bigquery.jobUser",
      ]
    }
    predict = {
      account_id   = "predict-runtime"
      display_name = "Predict runtime service account"
      roles = [
        "roles/bigquery.dataViewer",
        "roles/bigquery.jobUser",
        "roles/storage.objectViewer",
      ]
    }
    vm = {
      account_id   = "vm-runtime"
      display_name = "Compute VM service account"
      roles = [
        "roles/artifactregistry.reader",
        "roles/bigquery.dataViewer",
        "roles/bigquery.jobUser",
        "roles/logging.logWriter",
        "roles/monitoring.metricWriter",
        "roles/storage.objectViewer",
      ]
    }
  }

  service_account_bindings = {
    for binding in flatten([
      for name, config in local.service_accounts : [
        for role in config.roles : {
          key  = "${name}-${replace(role, "/", "-")}"
          name = name
          role = role
        }
      ]
    ]) : binding.key => binding
  }
}